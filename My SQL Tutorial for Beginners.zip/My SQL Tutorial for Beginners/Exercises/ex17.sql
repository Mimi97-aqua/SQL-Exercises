-- Write a query to produce the results with the following columns
--      customer_id, first_name, points, type

SELECT 
	customer_id,
    first_name,
    points,
    "bronze" AS type
FROM customers
WHERE points < 2000

UNION

SELECT 
	customer_id,
    first_name,
    points,
    "silver" AS type
FROM customers
WHERE points BETWEEN 2000 AND 3000


UNION 

SELECT 
	customer_id,
    first_name,
    points,
    "gold" AS type
FROM customers
WHERE points > 3000
ORDER BY first_name;