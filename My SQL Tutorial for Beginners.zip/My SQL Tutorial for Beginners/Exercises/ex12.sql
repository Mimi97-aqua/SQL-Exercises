-- Join payments table with payment_methods table alongside the clients
-- 		table. Produce a report that shows the payments with more details
-- 		such as the name of the client and the payment method

SELECT 
	c.name
    ,pm.name
FROM payments AS p
INNER JOIN payment_methods AS pm 
	ON p.payment_method = pm.payment_method_id
INNER JOIN clients AS c
	ON c.client_id = p.client_id;
