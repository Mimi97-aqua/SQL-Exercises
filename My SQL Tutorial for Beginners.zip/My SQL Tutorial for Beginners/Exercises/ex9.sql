-- Write query to get this result ->
--      Image here: https://ufile.io/7be0rttw

SELECT *
FROM order_items
WHERE order_id = 2
ORDER BY 
	product_id
    ,quantity
    ,unit_price;