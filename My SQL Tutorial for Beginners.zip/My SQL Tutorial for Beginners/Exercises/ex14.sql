-- Write a query that produces a result with the following columns:
-- 	order_date, order_id, first_name, shipper, status

USE sql_store;
SELECT 
	o.order_id
    ,o.order_date
    ,c.first_name AS customer
    ,s.name
    ,os.name AS status
FROM orders o
JOIN customers c
	ON	o.customer_id = c.customer_id
LEFT JOIN shippers s
	ON s.shipper_id = o.shipper_id
JOIN order_statuses os
	ON o.status = os.order_status_id;
    