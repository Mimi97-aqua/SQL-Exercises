-- For each order return the product_id as well as its name followed by the quantity and unit
-- 		price from the order_items table

SELECT 
	 order_id
    ,o.product_id
    ,p.name
    ,o.quantity
    ,o.unit_price
FROM order_items AS o
INNER JOIN products AS p
	ON o.product_id = p.product_id;