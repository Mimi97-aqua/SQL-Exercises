-- Get the customers whose 
-- 		ex 1: first names are ELKA or AMBUR 
-- 		ex 2: last names end with EY or ON
--  	ex 3: last names start with MY or contains SE
-- 		ex 4: last names contain B followed by R or U

-- ex1 
SELECT *
FROM customers
WHERE first_name REGEXP 'ELKA|AMBUR';

-- ex2 
SELECT *
FROM customers 
WHERE last_name REGEXP 'EY$|ON$';

-- ex3
SELECT * 
FROM customers 
WHERE last_name REGEXP '^MY|SE';

-- ex4
-- way 1
SELECT *
FROM customers 
WHERE last_name REGEXP '[B]R|[B]U';
-- way 2
SELECT *
FROM customers 
WHERE last_name REGEXP 'b[ru]';
-- way 3
SELECT * 
FROM customers
WHERE last_name REGEXP 'br|bu';