-- Get the customers whose 
-- 	addresses contain TRAIL or AVENUE
-- 	phone numbers end with 9

-- part one 
SELECT *
FROM customers 
WHERE address LIKE '%trail%' OR 
	   address LIKE '%avenue%';

-- part two 
SELECT *
FROM customers 
WHERE phone LIKE '%9';