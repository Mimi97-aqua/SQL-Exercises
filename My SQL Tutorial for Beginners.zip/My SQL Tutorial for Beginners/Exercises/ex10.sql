-- Get the top 3 loyal customers 
-- 		These are customers who have more points than everyone else
SELECT * 
FROM customers 
ORDER BY points DESC
LIMIT 3;