-- Do a cross join between shippers and products tables 
-- 	using both the implicit and explicit syntax 

-- implicit syntax 

SELECT * 
FROM shippers, customers;

-- explicit syntax 

SELECT *
FROM shippers 
CROSS JOIN customers;