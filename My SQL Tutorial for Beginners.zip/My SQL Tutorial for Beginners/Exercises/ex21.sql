-- In the orders table in sql store db 
-- Write sql code to update the comments for customers who have 
-- 		more than 3000 points to "Gold Customers"
UPDATE orders 
SET comments = "Gold customer"
WHERE customer_id IN (
						SELECT customer_id
						FROM customers
						WHERE points > 3000);