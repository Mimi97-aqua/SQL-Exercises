-- Write a statement to insert 3 rows in the products table 
INSERT INTO products (name, quantity_in_stock, unit_price)
VALUES ("prod1", 20, 3.0)
		,("prod2", 30, 4.3)
        ,("prod3", 50, 6.9);