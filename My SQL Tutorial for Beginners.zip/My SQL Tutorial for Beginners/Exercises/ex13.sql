-- Write a query that produces the columns product_id, name 
-- 		and quantity from the order_items table ie join the products
-- 		table and the order_items table to see how many times each 
-- 		product is ordered

SELECT 
	p.product_id
    ,p.name 
    ,oi.quantity
FROM products p
LEFT OUTER JOIN order_items oi
	ON p.product_id = oi.product_id;