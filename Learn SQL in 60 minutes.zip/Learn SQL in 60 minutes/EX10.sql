-- Get the Average Length of all Songs
-- Return the average length as Average Song Duration

SELECT 
AVG(length) AS 'Average Song Duration'
FROM songs;